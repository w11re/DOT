package com.bonnie.spring.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bonnie.spring.dao.Scores;
import com.bonnie.spring.dao.ScoresDAO;
import com.bonnie.spring.dao.UserDAO;
import com.bonnie.spring.dao.UserProfile;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;


@Controller
@RequestMapping("/dot")
public class RegistrationController {
	 


	 @RequestMapping(value = "/addUser/", method = RequestMethod.POST)
	 public @ResponseBody String addUser(HttpServletResponse response,
				HttpEntity<String> httpEntity) throws Exception {
			ObjectMapper mapper = new ObjectMapper();
			UserProfile createUser = null;
			try {
				createUser =
						mapper.readValue(httpEntity.getBody(), UserProfile.class); 
				UserDAO userDAO = new UserDAO();
				userDAO.addUser(createUser);
				return  "{\"status\": \"success\"}";
			}catch (Exception ex ){
				return  "{\"status\": \"fail\"}";
			}
	 } 
	 
	 
	 @RequestMapping(value = "/addScore/", method = RequestMethod.POST)
	 @ResponseBody
	 public String addScore(HttpServletResponse response,
				HttpEntity<String> httpEntity) throws Exception {
		 
		 ObjectMapper mapper = new ObjectMapper();
		 Scores  scoreFromTest = null; 
			  try{
				
		        scoreFromTest = mapper.readValue(httpEntity.getBody(), Scores.class);
		        ScoresDAO scoresDAO = new ScoresDAO();
		        scoresDAO.addScore(scoreFromTest);
		        String scoreVal = String.valueOf(scoreFromTest.getTestWPM());
		        return  "{\"status\": \"success\", \"score\": scoreVal}";
			  }catch(Exception ex){
				  String scoreVal = String.valueOf(scoreFromTest.getTestWPM());
				  return  "{\"status\": \"fail\", \"score\": scoreVal}";
			  }
	 }
	 
	 @RequestMapping(value = "/getScores", method = RequestMethod.GET)
	 public @ResponseBody String getAllScores(
				@RequestParam("userEmail") String userEmail,
				HttpServletResponse response) throws Exception {
	
		String strScores = null;
		try{
			UserDAO userDAO = new UserDAO();
			//UserProfile user = userDAO.readUser(userEmail);
			UserProfile user = new UserProfile();
			user.setUserID(10);
			if (user != null){
				ScoresDAO scoresDAO = new ScoresDAO();
				//ArrayList<Scores>  scores = scoresDAO.getScore(user.getUserID());
				ArrayList<Scores> scores = mockScores();
				//Convert to JSONObject or JSONArray?
				Gson gson = new Gson();
		        strScores = gson.toJson(scores);
		        System.out.println(" SCORES " + strScores);
			}
		}catch(Exception ex){
			ex.printStackTrace();
			return strScores;
		}
		
		return strScores;
	 }


	private ArrayList<Scores> mockScores() {
		ArrayList<Scores>  scores = new ArrayList<Scores> ();
		for (int i = 1; i <= 5; i++){
			Scores score = new Scores();
			score.setUserID(10);
			score.setTestID(i);
			score.setTestWPM(i * 10);
			scores.add(score);
		}
		return scores;
	}
	 
}