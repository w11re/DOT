package com.bonnie.spring.dao;

import java.io.Serializable;

public class Scores implements Serializable{
	int scoreID;
	int userID;
	int testWPM;
	int testID;
	
	public int getScoreID() {
		return scoreID;
	}
	public void setScoreID(int scoreID) {
		this.scoreID = scoreID;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public int getTestWPM() {
		return testWPM;
	}
	public void setTestWPM(int testWPM) {
		this.testWPM = testWPM;
	}
	public int getTestID() {
		return testID;
	}
	public void setTestID(int testID) {
		this.testID = testID;
	}
}
